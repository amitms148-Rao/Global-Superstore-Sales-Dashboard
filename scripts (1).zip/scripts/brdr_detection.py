import pandas as pd
import numpy as np
import os
import csv
import cv2

input_data = "/kaggle/input/input-data/input"
output = "/kaggle/working/report.csv"

def find_border(path): 
    image = cv2.imread(path, 0)
    if image is None:
        return 0,0,0,0, "No image Found"

    height = image.shape[0]
    width = image.shape[1]

    up_bdr = 0
    down_bdr = 0
    right_bdr = 0
    left_bdr = 0


    brghtness = image.mean()

    if abs(image[0].mean() - brghtness) > 10:
        for i in range(height):
            if abs(image[i].mean() - brghtness) < 10:
                up_bdr = i
                break
                
    if abs(image[-1].mean() - brghtness) > 10:
        for i in range(height-1, -1, -1):
            if abs(image[i].mean() - brghtness) < 10:
                down_bdr = height - i
                break
                
    if abs(image[:, 0].mean() - brghtness) > 10:
        for i in range (width):
            if abs(image[:, i].mean() - brghtness) < 10:
                left_bdr = i
                break

    if abs(image[:, -1].mean() - brghtness) > 10:
        for i in range (width-1, -1, -1):
            if abs (image [:, i].mean() - brghtness) < 10: 
                right_bdr = width - i
                break

    return up_bdr, down_bdr, right_bdr, left_bdr, ""

if __name__ == "__main__":
    with open(output, 'w', newline = '') as f:
    writer = csv.writer(f)
    writer.writerow(['Image Name', 'Top Border', 'Bottom Border', 'Left Border', 'Right Broder', 'Error'])

    for file in os.listdir(input_data):
        if file.endswith('.jpg'):
            full_path = os.path.join(input_data, file)
            top, bottom, left, right, error = find_border(full_path)

            if error: 
                writer.writerow([file, 0,0,0,0, error])
            else:
                writer.writerow([file, top, bottom, left, right, ""])