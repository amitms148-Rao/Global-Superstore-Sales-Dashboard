import pandas as pd
import numpy as np
import os
import csv
import cv2

input_data = "/kaggle/input/input-data/input"
output_data = "/kaggle/working/cropped_images"

def crop_border (images_pth, cropped_pth):
    image = cv2.imread(images_pth)
    if image is None:
        print(f"No image found")
        return False

    gray_scale = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
    height = gray_scale.shape[0]
    width = gray_scale.shape[1]

    top = 0
    bottom = height 
    left = 0
    right = width

    color = gray_scale.mean()

    if abs(gray_scale[0].mean() - color) > 20:
        for i in range(height):
            if abs(gray_scale[i].mean() - color) < 20:
                top = i
                break

    if abs(gray_scale[-1].mean() - color) > 20:
        for i in range(height-1, -1, -1):
            if abs(gray_scale[i].mean() - color) < 20:
                bottom = i
                break

    if abs(gray_scale[:, 0].mean() - color) > 20:
        for i in range(width):
            if abs(gray_scale[:, i].mean() - color) < 20:
                left = i
                break

    if abs(gray_scale[:, -1].mean() - color) > 20:
        for i in range( width-1, -1, -1):
            if abs(gray_scale[:, i].mean() - color) < 20:
                right = i
                break

    cropped_image = image[top:bottom, left:right]
    cv2.imwrite(cropped_pth, cropped_image)
    return True

if __name__ == "__main__":
    for file in os.listdir(input_data):
    if file.endswith('.jpg'):
        input_path = os.path.join(input_data, file)
        output_path = os.path.join(output_data, file)

    if crop_border(input_path, output_path):
        print(f"Done {file}")
    else:
        print(f"Problem with {file}")